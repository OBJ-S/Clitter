# Build Clitter as an Android APK

The frontend now uses app-like touch behavior (no long-press text selection/context menu, no pinch/double-tap page zoom, no browser blue tap highlight) and has distinct active colors for Home, Create, My Clips, and Plans. To create an actual installable APK, wrap it with Capacitor.

## Build on a computer
1. Install Node.js LTS and Android Studio (including Android SDK).
2. Extract this ZIP and open a terminal in the `clitter/` folder.
3. Run:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install the generated debug APK on your Android device.

## Important
- This ZIP is the app source plus Capacitor setup, not a prebuilt APK. A native APK needs Android's build tools (Android Studio/SDK).
- Keep the Supabase Project URL and publishable key in the frontend only. Never add a Supabase secret/service-role key to this project.
- Supabase Auth redirect URLs must be configured for the origin used by the app. For a production native app, review the auth redirect/deep-link setup before relying on email confirmation redirects.
